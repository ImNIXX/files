from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home_page, name="home-page"),
    # LOGIN
    path('login/', views.login_page, name="login"),
    path('login-user/', views.user_login, name="login-user"),
    # LOGOUT
    path('user-logout/', views.logout, name="user-logout"),
    # SIGN IN
    path('signup/', views.signup_page, name="signup"),
    path('add-user/', views.insert_user, name="add-user"),
    path('check-username/', views.check_username, name="check-username"),
    # INSERT INSPECTION
    path('insert_the_inspection/', views.insert_inspection, name="insert_the_inspection"),
    # GET INSPECTION
    path('get-inspection/', views.get_inspection, name="get-inspection"),
    # UPDATE INSPECTION
    path('update-inspection/', views.update_inspection, name="update-inspection"),
    # DELETE INSPECTION
    path('del-insp/', views.delete_inspection, name="del-insp"),
    # DRAFT
    path('inspection-draft/', views.drafts_show, name="inspection-draft"),
    path('insert-draft/', views.insert_draft, name="insert-draft"),
    path('insert-draft-form/', views.insert_draft_form, name="insert-draft-form"),
    path('view-draft', views.view_draft, name="view-draft"),
    path('update-drafts', views.update_drafts, name="update-drafts"),
    # DRAFT FORM UPDATE
    path('update-draft/', views.update_draft, name="update-draft"),
    # APPROVE INSPECTION
    path('inspection-approve/', views.insp_approve, name="inspection-approve"),
    # SEARCH INSPECTIONS
    path('inspection-search/', views.insp_search, name="inspection-search"),
    # FILTER INSPECTIONS
    path('inspection-filter/', views.insp_filter, name="inspection-filter"),
    # DOWNLOAD DRAFTS PDF
    path('draft-pdf/', views.get_draft_pdf, name="draft-pdf"),
    # CAPA
    path('', include('core.urls')),
    path('member/', views.home, name='home'),
    path('member/capa/capa_list', views.capa_list, name='capa_list'),
    path('member/capa/create_capa_display/<str:module>/<str:module_key>/<str:js_call>/<str:capa_id>', views.create_capa_display, name='create_capa_display'),
    path('member/capa/create_capa/<str:module>/<str:module_key>/', views.create_capa, name='create_capa'),
    path('member/capa/update_capa/', views.update_capa, name='update_capa'),
    path('member/capa/delete_capa/', views.delete_capa, name='delete_capa'),
    path('member/capa/get_capa/', views.get_capa, name='get_capa'),
    path('member/capa/send_reminder/', views.send_reminder, name='send_reminder'),
]

